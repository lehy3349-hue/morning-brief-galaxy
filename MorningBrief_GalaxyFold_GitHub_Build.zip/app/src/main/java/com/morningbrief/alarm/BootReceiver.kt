package com.morningbrief.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
class BootReceiver: BroadcastReceiver() {
 override fun onReceive(context: Context, intent: Intent) {
  val p=context.getSharedPreferences("alarm",Context.MODE_PRIVATE)
  if(p.getBoolean("enabled",false)) AlarmScheduler.schedule(context,p.getInt("hour",7),p.getInt("minute",0))
 }
}
