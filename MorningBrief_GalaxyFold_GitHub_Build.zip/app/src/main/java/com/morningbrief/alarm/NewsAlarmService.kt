package com.morningbrief.alarm

import android.app.*
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NewsAlarmService: Service(), TextToSpeech.OnInitListener {
 private var tts: TextToSpeech?=null
 private var focus: AudioFocusRequest?=null
 override fun onBind(intent:Intent?):IBinder?=null
 override fun onCreate(){super.onCreate(); val manager=getSystemService(NotificationManager::class.java)
  manager.createNotificationChannel(NotificationChannel("alarm","뉴스 음성 알람",NotificationManager.IMPORTANCE_HIGH).apply { lockscreenVisibility=Notification.VISIBILITY_PUBLIC })
  val launch=PendingIntent.getActivity(this,3,Intent(this,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  val stop=PendingIntent.getService(this,4,Intent(this,NewsAlarmService::class.java).setAction("STOP"),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  val notification=Notification.Builder(this,"alarm").setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Morning Brief 뉴스 알람").setContentText("뉴스 음성을 재생하고 있습니다").setCategory(Notification.CATEGORY_ALARM).setVisibility(Notification.VISIBILITY_PUBLIC).setOngoing(true).setContentIntent(launch).setFullScreenIntent(launch,true).addAction(Notification.Action.Builder(null,"알람 종료",stop).build()).build()
  startForeground(101,notification)
  val audio=getSystemService(AudioManager::class.java)
  focus=AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT).setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()).build()
  audio.requestAudioFocus(focus!!)
  tts=TextToSpeech(this,this)
 }
 override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int { if(intent?.action=="STOP") {stopSelf();return START_NOT_STICKY};return START_NOT_STICKY }
 override fun onInit(status:Int){ if(status!=TextToSpeech.SUCCESS){stopSelf();return}; val engine=tts?:return
  engine.language=Locale.KOREAN
  val korean=engine.voices?.filter { it.locale.language=="ko" && !it.isNetworkConnectionRequired }
  val female=korean?.firstOrNull { it.name.contains("female",true) || it.name.contains("여성") }
  if(female!=null)engine.voice=female else if(!korean.isNullOrEmpty())engine.voice=korean.first()
  engine.setSpeechRate(0.9f)
  val p=getSharedPreferences("alarm",MODE_PRIVATE)
  val date=SimpleDateFormat("M월 d일 EEEE",Locale.KOREAN).format(Date())
  val cached=p.getString("headlines","").orEmpty()
  val savedAt=p.getLong("savedAt",0)
  val fresh=cached.isNotBlank() && System.currentTimeMillis()-savedAt < 24L*60*60*1000
  val text="좋은 아침입니다. $date, 모닝 브리프입니다. " + if(fresh) "오늘 준비된 주요 뉴스입니다. $cached" else "최신 뉴스를 미리 저장하지 못했습니다. 앱을 열어 뉴스 새로고침을 해주세요."
  engine.speak(text,TextToSpeech.QUEUE_FLUSH,null,"morning_news")
 }
 override fun onDestroy(){tts?.stop();tts?.shutdown();focus?.let{getSystemService(AudioManager::class.java).abandonAudioFocusRequest(it)};super.onDestroy()}
}
