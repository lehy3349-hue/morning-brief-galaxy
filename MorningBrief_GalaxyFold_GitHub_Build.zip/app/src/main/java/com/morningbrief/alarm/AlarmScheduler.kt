package com.morningbrief.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object AlarmScheduler {
 fun schedule(context: Context, hour: Int, minute: Int): Boolean {
  val am = context.getSystemService(AlarmManager::class.java)
  if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) return false
  val prefs = context.getSharedPreferences("alarm", Context.MODE_PRIVATE)
  prefs.edit().putInt("hour",hour).putInt("minute",minute).putBoolean("enabled",true).apply()
  val at = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY,hour); set(Calendar.MINUTE,minute); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DATE,1) }
  val pi = PendingIntent.getBroadcast(context, 1, Intent(context,AlarmReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  am.setAlarmClock(AlarmManager.AlarmClockInfo(at.timeInMillis, PendingIntent.getActivity(context,2,Intent(context,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)),pi)
  return true
 }
 fun cancel(context: Context) {
  val pi = PendingIntent.getBroadcast(context,1,Intent(context,AlarmReceiver::class.java),PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
  if(pi != null) context.getSystemService(AlarmManager::class.java).cancel(pi)
  context.getSharedPreferences("alarm",Context.MODE_PRIVATE).edit().putBoolean("enabled",false).apply()
 }
}
