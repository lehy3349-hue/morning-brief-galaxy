package com.morningbrief.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
 override fun onReceive(context: Context, intent: Intent) {
  context.startForegroundService(Intent(context,NewsAlarmService::class.java))
  val p=context.getSharedPreferences("alarm",Context.MODE_PRIVATE)
  if(p.getBoolean("enabled",false)) AlarmScheduler.schedule(context,p.getInt("hour",7),p.getInt("minute",0))
 }
}
