package com.morningbrief.alarm

import android.Manifest
import android.app.*
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import javax.xml.parsers.DocumentBuilderFactory

class MainActivity:Activity(){
 private lateinit var status:TextView
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setShowWhenLocked(true);setTurnScreenOn(true)
  val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(36,55,36,30);setBackgroundColor(0xff101827.toInt()) }
  fun label(s:String,size:Float=17f):TextView=TextView(this).apply {text=s;textSize=size;setTextColor(-1);setPadding(0,12,0,12)}
  root.addView(label("MORNING BRIEF",29f));root.addView(label("벨소리 없이, 뉴스로 시작하는 아침"))
  val picker=TimePicker(this).apply {setIs24HourView(true);hour=7;minute=0};root.addView(picker)
  status=label("알람을 설정하고 뉴스를 미리 받아주세요.");root.addView(status)
  fun button(s:String, action:()->Unit){root.addView(Button(this).apply{text=s;setOnClickListener{action()}})}
  button("알람 저장 (매일)") {
   if(AlarmScheduler.schedule(this,picker.hour,picker.minute))status.text="매일 %02d:%02d 알람 설정 완료".format(picker.hour,picker.minute)
   else {status.text="정확한 알람 권한을 허용해주세요";if(Build.VERSION.SDK_INT>=31)startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))}
  }
  button("최신 뉴스 가져오기 (KBS RSS)"){ status.text="뉴스를 가져오는 중...";Thread {
   try { val conn=URL("https://news.kbs.co.kr/rss/rss.xml").openConnection().apply{connectTimeout=8000;readTimeout=8000};val stream=conn.getInputStream()
    val factory=DocumentBuilderFactory.newInstance().apply {setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);setFeature("http://xml.org/sax/features/external-general-entities",false);setFeature("http://xml.org/sax/features/external-parameter-entities",false)}
    val doc=stream.use{factory.newDocumentBuilder().parse(it)};val items=doc.getElementsByTagName("item")
    val headlines=(0 until minOf(items.length,5)).mapNotNull { i->val title=(items.item(i) as? org.w3c.dom.Element)?.getElementsByTagName("title")?.item(0)?.textContent?.trim();title?.takeIf{it.isNotBlank()} }.joinToString(". 다음 소식입니다. ")
    if(headlines.isBlank())error("뉴스가 없습니다")
    getSharedPreferences("alarm",MODE_PRIVATE).edit().putString("headlines",headlines).putLong("savedAt",System.currentTimeMillis()).apply()
    runOnUiThread{status.text="뉴스 ${minOf(items.length,5)}건 저장 완료. 알람 때 제목을 읽어줍니다."}
   }catch(e:Exception){runOnUiThread{status.text="뉴스 수신 실패: ${e.message}"}}
  }.start() }
  button("지금 뉴스 음성 테스트") { startForegroundService(Intent(this,NewsAlarmService::class.java)) }
  button("음성 종료") {stopService(Intent(this,NewsAlarmService::class.java))}
  button("알람 해제") {AlarmScheduler.cancel(this);status.text="알람 해제됨"}
  root.addView(label("※ 음성은 기기 한국어 TTS 엔진에 따라 달라집니다. 여성 음성이 없으면 한국어 기본 음성으로 재생됩니다.",13f))
  val scroll=ScrollView(this);scroll.addView(root);setContentView(scroll)
  if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),11)
 }
}
