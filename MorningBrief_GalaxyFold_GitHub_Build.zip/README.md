# Morning Brief Android (Galaxy Z Fold) — prototype

Android Studio에서 폴더를 열고 Gradle Sync 후 Build > Build APK(s)로 빌드합니다. APK를 갤럭시로 전송해 설치하세요.

## 기능
- AlarmManager.setAlarmClock: 매일 지정 시각에 정확한 알람 요청 (권한 필요)
- 잠금 화면에서 알람 전체화면 알림 시도, foreground mediaPlayback 서비스로 TTS 재생
- KBS RSS에서 기사 제목 최대 5개 수신, 24시간 이내 캐시만 알람에 사용
- 한국어 여성 음성 이름을 우선 탐색 (기기 TTS에 없으면 기본 한국어 음성)
- 재부팅 후 알람 복원

## 필수 테스트
1. 설정 > 앱 > Morning Brief > 알림 허용, 알람 및 리마인더 권한 허용
2. 삼성 배터리 설정에서 앱 절전 예외 적용
3. 한국어 TTS 음성 데이터 설치 및 여성 음성 선택
4. 뉴스 새로고침, 음성 테스트
5. 2분 뒤 알람 설정 후 화면 잠금 상태 테스트
6. 재부팅 후 알람 복원 테스트

## 제한 사항
- 이 파일은 소스 프로젝트이며 APK가 아닙니다. 현재 환경에는 Android SDK/Gradle 빌드 환경이 없어 APK 빌드 및 실기기 테스트를 수행하지 못했습니다.
- 현재 뉴스는 **기사 본문 요약이 아닌 제목 낭독**입니다. RSS 제공자의 주소/정책 변경 시 실패할 수 있습니다.
- 여성 음성은 제조사 TTS 엔진의 실제 설치 음성에 의존하며 보장되지 않습니다.
- 기기/OS 정책에 따라 잠금 화면 전체화면 표시 및 백그라운드 음성 동작에 차이가 있을 수 있습니다.
- 초기 테스트 코드로, 상용 배포 전 예외 처리, 뉴스 라이선스, 접근성, 반복 재생, 음성 종료 이벤트 등을 보강해야 합니다.

## GitHub Actions에서 APK 만들기
1. GitHub에서 비공개 저장소 `morning-brief-galaxy`를 새로 만듭니다.
2. 이 ZIP을 풀어 **폴더 안의 파일 전체**(`.github` 폴더 포함)를 저장소 최상위에 업로드합니다.
3. 저장소 Actions > Build Galaxy APK > Run workflow를 누릅니다.
4. 성공한 실행의 Artifacts에서 `MorningBrief-GalaxyFold-debug-apk`를 다운로드하고 ZIP을 풉니다.
5. `app-debug.apk`를 갤럭시에서 열어 설치합니다. 설치 전 권한/보안 경고를 확인하세요.

주의: 아직 실제 GitHub Actions 빌드 성공이나 기기 동작이 검증된 것은 아닙니다. 이 테스트 앱은 뉴스 수집 버튼을 눌러 미리 제목을 저장해야 하며, 자동 갱신은 아직 구현되지 않았습니다.
